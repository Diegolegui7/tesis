<?php
// Demostración guiada paso a paso (solo para pruebas locales).
// El sistema mira la base de datos en tiempo real: cuando la persona hace lo que dice un paso, el paso se marca como hecho y aparece el siguiente.
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/util.php';

const DEMO_CLIENTE_ID = 6;                              // Exportadora Nueva S.R.L. (cliente nuevo, sin reservas)
const DEMO_CARLOS = 'cnuevo@exportadoranueva.com';
const DEMO_MARINA = 'msosa@arpaflu.com';

function demo_get($clave)
{
    try { return valor('SELECT valor FROM demo WHERE clave = ?', [$clave]); } catch (Exception $e) { return null; }
}

function demo_set($clave, $valor)
{
    ejecutar('INSERT INTO demo (clave, valor) VALUES (?,?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)', [$clave, $valor]);
}

function demo_activa()
{
    return MODO_DEMO && demo_get('activo') === '1';
}

// Operación que nació del pedido del cliente de la demostración (la última aceptada)
function demo_operacion_id()
{
    return (int) valor("SELECT operacion_id FROM solicitudes WHERE cliente_id = ? AND estado = 'aceptada' AND operacion_id IS NOT NULL ORDER BY id DESC LIMIT 1", [DEMO_CLIENTE_ID]);
}

// La reserva de la demostración ya zarpó o se canceló: los pasos que necesitan una reserva abierta ya no se pueden hacer
function demo_reserva_cerrada()
{
    $o = demo_operacion_id();
    return $o && in_array(valor('SELECT estado FROM operaciones WHERE id = ?', [$o]), ['zarpado', 'cancelada'], true);
}

// Pasos de la demostración. Cada “check” recibe el momento desde el cual contar y devuelve el momento en que se cumplió (o null).
// “texto”: de qué se trata (una frase). “pasos”: qué tocar, con las palabras que aparecen en pantalla.
// “ir”: la pantalla donde se hace. “resaltar”: lo que la guía marca en naranja en esa pantalla (selector y, si hace falta, un texto que debe contener).
function demo_pasos()
{
    return [
        ['id' => 1, 'secuencial' => true, 'quien' => DEMO_CARLOS, 'titulo' => 'Entrá como el cliente',
         'texto' => 'Vas a hacer de Carlos, de una empresa que nunca usó el sistema.',
         'pasos' => ['Tocá el botón azul “Entrar como Carlos”, acá abajo.'],
         'check' => function ($t0) { return valor('SELECT 1 FROM usuarios WHERE id = 12 AND ultimo_ingreso >= ?', [$t0]) ? $t0 : null; }],
        ['id' => 2, 'ir' => ['Ir a “Pedir una reserva”', 'cliente/pedir.php'], 'resaltar' => ['#form-pedido'], 'quien' => DEMO_CARLOS, 'titulo' => 'Pedí lugar en un barco',
         'texto' => 'Carlos necesita mandar su carga y pide lugar desde el portal.',
         'pasos' => ['En “1. Elegí el barco”, tocá uno de los barcos que tienen lugar.', 'En “2. Contanos qué necesitás”, poné cuántos contenedores querés.', 'Tocá “Enviar pedido” y confirmá.'],
         'check' => function ($t0) { return valor('SELECT MIN(creado) FROM solicitudes WHERE cliente_id = ? AND creado >= ?', [DEMO_CLIENTE_ID, $t0]); }],
        ['id' => 3, 'secuencial' => true, 'quien' => DEMO_MARINA, 'titulo' => 'Cambiá de lado: ahora sos ARPAFLU',
         'texto' => 'Marina es la empleada de ARPAFLU que atiende a Carlos.',
         'pasos' => ['Tocá el botón azul “Entrar como Marina”, acá abajo.'],
         'check' => function ($t0) { return valor('SELECT 1 FROM usuarios WHERE id = 2 AND ultimo_ingreso >= ?', [$t0]) ? $t0 : null; }],
        ['id' => 4, 'ir' => ['Ir a “Pedidos de clientes”', 'personal/pedidos.php'], 'resaltar' => ['#pendientes tbody tr', 'Exportadora Nueva'], 'quien' => DEMO_MARINA, 'titulo' => 'Aceptá el pedido de Carlos',
         'texto' => 'A Marina le llegó el pedido de Carlos.',
         'pasos' => ['Buscá la fila de “Exportadora Nueva S.R.L.” (está marcada en naranja).', 'Tocá el botón azul “Aceptar”.', 'Listo: el sistema crea la reserva solo.'],
         'check' => function ($t0) { return valor("SELECT MAX(respondido_en) FROM solicitudes WHERE cliente_id = ? AND estado = 'aceptada' AND respondido_en >= ?", [DEMO_CLIENTE_ID, $t0]); }],
        ['id' => 5, 'ir' => ['Ir a “Inicio”', 'cliente/reservas.php'], 'resaltar' => ['#pedidos + .reserva-tarjeta'], 'quien' => DEMO_CARLOS, 'titulo' => 'Mirá tu reserva como cliente',
         'texto' => 'Carlos se entera de que su pedido fue aceptado.',
         'pasos' => ['Mirá el cuadro marcado en naranja: dice “Aceptado. Tu reserva es la ARP-…”.', 'No hace falta tocar nada: con verlo, el paso se completa solo.'],
         'check' => function ($t0) { return valor("SELECT MAX(visto_cliente) FROM solicitudes WHERE cliente_id = ? AND estado = 'aceptada' AND visto_cliente >= ?", [DEMO_CLIENTE_ID, $t0]); }],
        ['id' => 6, 'imposible' => 'demo_reserva_cerrada', 'ir' => ['Ir a la reserva', 'personal/operacion.php?id={op}'], 'resaltar' => ['.que-sigue'], 'quien' => DEMO_MARINA, 'titulo' => 'Cargá el número de booking',
         'texto' => 'La naviera confirmó el lugar en el barco y mandó su número de reserva (el “booking”).',
         'pasos' => ['Arriba de todo está el recuadro “Qué sigue · Cargar el número de booking” (marcado en naranja).', 'En “Número de booking” escribí 254AR0099001.', 'Tocá “Guardar el booking”.'],
         'check' => function ($t0) { $o = demo_operacion_id(); return $o ? valor('SELECT booking_confirmado_en FROM operaciones WHERE id = ? AND booking_confirmado_en >= ?', [$o, $t0]) : null; }],
        ['id' => 7, 'imposible' => 'demo_reserva_cerrada', 'ir' => ['Ir a la reserva', 'personal/operacion.php?id={op}#cambios'], 'resaltar' => ['#cambios form.tarjeta'], 'quien' => DEMO_MARINA, 'titulo' => 'Avisá que cambió el barco',
         'texto' => 'La naviera pasó la carga a otro barco (eso se llama “roleo”).',
         'pasos' => ['Andá al recuadro “Avisar un cambio” (marcado en naranja).', 'En “Qué cambió” elegí “El barco se corre (roleo): nuevo barco y fechas”.', 'En “Cómo queda” escribí un barco, por ejemplo MSC Lena V.644S.', 'Tocá “Guardar y avisar”.'],
         'check' => function ($t0) { $o = demo_operacion_id(); return $o ? valor("SELECT MIN(creado) FROM historial_cambios WHERE operacion_id = ? AND dato LIKE 'Roleo%' AND creado >= ?", [$o, $t0]) : null; }],
        ['id' => 8, 'imposible' => 'demo_reserva_cerrada', 'ir' => ['Ir a mi reserva', 'cliente/operacion.php?id={op}'], 'resaltar' => ['#avisos'], 'quien' => DEMO_CARLOS, 'titulo' => 'Confirmá que leíste el aviso',
         'texto' => 'A Carlos le llegó el aviso del cambio de barco.',
         'pasos' => ['Mirá el aviso marcado en naranja.', 'Tocá “Notado: ya lo leí”.'],
         'check' => function ($t0) { $o = demo_operacion_id(); return $o ? valor("SELECT MIN(notado_en) FROM comunicaciones WHERE operacion_id = ? AND destinatario_correo = ? AND notado_en >= ?", [$o, DEMO_CARLOS, $t0]) : null; }],
        ['id' => 9, 'imposible' => 'demo_reserva_cerrada', 'ir' => ['Ir a mi reserva', 'cliente/operacion.php?id={op}#enviar'], 'resaltar' => ['#enviar'], 'quien' => DEMO_CARLOS, 'titulo' => 'Mandá un documento',
         'texto' => 'Carlos le manda a ARPAFLU un papel de su carga.',
         'pasos' => ['Andá al recuadro “Enviar documento” (marcado en naranja).', 'En “¿Qué documento es?” elegí cualquiera.', 'En “Archivo” elegí cualquier PDF o foto de tu compu.', 'Tocá “Enviar documento”.'],
         'check' => function ($t0) { $o = demo_operacion_id(); return $o ? valor('SELECT MIN(creado) FROM documentos WHERE operacion_id = ? AND subido_por = 12 AND creado >= ?', [$o, $t0]) : null; }],
        ['id' => 10, 'imposible' => 'demo_reserva_cerrada', 'ir' => ['Ir a la reserva', 'personal/operacion.php?id={op}'], 'resaltar' => ['.que-sigue'], 'quien' => DEMO_MARINA, 'titulo' => 'Cargá la orden de retiro',
         'texto' => 'La naviera mandó el permiso para ir a buscar el contenedor vacío.',
         'pasos' => ['Arriba de todo está el recuadro “Qué sigue · Registrar la orden de retiro” (marcado en naranja).', 'En “Número de la orden” escribí OR-5521.', 'Tocá “Guardar la orden de retiro”.'],
         'check' => function ($t0) { $o = demo_operacion_id(); return $o ? valor("SELECT MIN(creado) FROM comunicaciones WHERE operacion_id = ? AND evento = 'Orden de retiro recibida' AND creado >= ?", [$o, $t0]) : null; }],
        ['id' => 11, 'ir' => ['Ir a la reserva', 'personal/operacion.php?id={op}'], 'resaltar' => ['.que-sigue'], 'quien' => DEMO_MARINA, 'titulo' => 'Avisá que salió el barco',
         'texto' => 'El barco zarpó: es el último paso de una reserva.',
         'pasos' => ['Arriba de todo está el recuadro “Qué sigue · Avisar cuando el barco salga” (marcado en naranja).', 'Tocá “El barco ya salió” y confirmá.'],
         'check' => function ($t0) { $o = demo_operacion_id(); return $o ? valor('SELECT zarpe_confirmado FROM operaciones WHERE id = ? AND zarpe_confirmado >= ?', [$o, $t0]) : null; }],
        ['id' => 12, 'ir' => ['Ir a “Lugar disponible”', 'personal/disponibilidad.php'], 'resaltar' => ['button', 'Cerrar todos'], 'quien' => DEMO_MARINA, 'titulo' => 'Cerrá el lugar disponible',
         'texto' => 'Ahora vamos a ver qué pasa cuando no queda lugar en ningún barco.',
         'pasos' => ['Tocá el botón “Cerrar todos los abiertos” (marcado en naranja).', 'Confirmá.'],
         'check' => function ($t0) { require_once __DIR__ . '/solicitudes.php'; return count(disponibilidades(true)) === 0 ? valor('SELECT NOW()') : null; }],
        ['id' => 13, 'ir' => ['Ir a “Pedir una reserva”', 'cliente/pedir.php'], 'resaltar' => ['.sin-disponibilidad'], 'quien' => DEMO_CARLOS, 'titulo' => 'Mirá qué ve el cliente sin lugar',
         'texto' => 'Carlos quiere pedir lugar otra vez, pero ya no hay.',
         'pasos' => ['Leé el mensaje marcado en naranja: “Por ahora no hay lugar disponible”.', 'Con verlo, la demo termina.'],
         'check' => function ($t0) { $v = demo_get('vio_sin_lugar'); return $v && $v >= $t0 ? $v : null; }],
    ];
}

// Estado actual de la guía: cada paso con si está hecho y cuál es el que sigue
function demo_estado()
{
    $inicio = demo_get('inicio');
    if (!$inicio) { return null; }
    $omitidos = array_filter(explode(',', (string) demo_get('omitidos')));
    $pasos = demo_pasos();
    $t0 = $inicio;
    $actual = null;
    $nombres = [DEMO_CARLOS => 'Carlos (cliente)', DEMO_MARINA => 'Marina (ARPAFLU)'];
    foreach ($pasos as $i => &$p) {
        $hecho = false;
        if ($actual === null) {
            if (in_array((string) $p['id'], $omitidos, true)) {
                $hecho = true;
                $p['omitido'] = true;
            } else {
                $t = $p['check'](!empty($p['secuencial']) ? $t0 : $inicio);
                if ($t) {
                    $hecho = true;
                    if ($t > $t0) { $t0 = $t; }
                } elseif (isset($p['imposible']) && call_user_func($p['imposible'])) {
                    $hecho = true;
                    $p['omitido'] = true;
                    $p['nota'] = 'Se salteó solo: la reserva ya zarpó y este paso ya no se puede hacer.';
                }
            }
        }
        $p['hecho'] = $hecho;
        $p['quien_nombre'] = $nombres[$p['quien']];
        if (isset($p['ir'])) {
            $op = strpos($p['ir'][1], '{op}') !== false ? demo_operacion_id() : 1;
            $p['ir'] = $op ? ['texto' => $p['ir'][0], 'ruta' => str_replace('{op}', (string) $op, $p['ir'][1])] : null;
        }
        if (!$hecho && $actual === null) { $actual = $i; }
        unset($p['check'], $p['imposible'], $p['secuencial']);
    }
    unset($p);
    return ['pasos' => $pasos, 'actual' => $actual, 'total' => count($pasos), 'terminado' => $actual === null, 'inicio' => $inicio];
}

// Panel flotante con la guía (se muestra en todas las pantallas mientras la demostración esté activa)
function demo_panel()
{
    if (!MODO_DEMO) { return; }
    try { $activa = demo_activa(); } catch (Exception $e) { return; }
    if (!$activa) { return; }
    $b = base_url();
    ?>
<aside id="demo-panel" class="demo-panel" data-base="<?= e($b) ?>" data-csrf="<?= e(csrf_token()) ?>" aria-live="polite">
  <div class="demo-cab" id="demo-cab" title="Arrastrá la barra para mover el cuadro · doble clic en :::: para volverlo a su lugar">
    <strong>Demo guiada</strong>
    <span class="demo-manija" id="demo-manija" aria-hidden="true">::::</span>
    <span id="demo-prog" class="demo-prog"></span>
    <button type="button" id="demo-min" class="demo-btn-icono" aria-label="Achicar o agrandar la guía" title="Achicar">–</button>
  </div>
  <div class="demo-cuerpo" id="demo-cuerpo">
    <div class="demo-barra"><div id="demo-barra-i"></div></div>
    <div id="demo-ok" class="demo-ok" hidden></div>
    <h3 id="demo-titulo">Cargando…</h3>
    <p id="demo-texto"></p>
    <div id="demo-quien" class="demo-quien"></div>
    <div class="demo-acciones">
      <button type="button" class="demo-enlace" id="demo-saltar">Saltar este paso</button>
      <button type="button" class="demo-enlace" id="demo-reiniciar">Reiniciar la demo</button>
      <button type="button" class="demo-enlace" id="demo-ocultar">Ocultar guía</button>
    </div>
  </div>
</aside>
<script src="<?= e($b) ?>js/demo.js?v=<?= (int) @filemtime(__DIR__ . '/../js/demo.js') ?>"></script>
<?php
}
