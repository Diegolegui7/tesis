// ARPAFLU · comportamiento de la interfaz
// Solo maneja la interfaz; los datos y las reglas del negocio los resuelve PHP en el servidor.
 
document.addEventListener('DOMContentLoaded', function () {
 
  // Menú lateral en pantallas chicas
  var botonMenu = document.querySelector('.boton-menu');
  var velo = document.querySelector('.velo');
  if (botonMenu) {
    botonMenu.addEventListener('click', function () {
      document.body.classList.toggle('menu-abierto');
    });
  }
  if (velo) {
    velo.addEventListener('click', function () {
      document.body.classList.remove('menu-abierto');
    });
  }
 
  // Pestañas: <button class="pestana" data-pestana="id"> abre <section class="panel-pestana" id="id">
  document.querySelectorAll('.pestanas').forEach(function (grupo) {
    var botones = grupo.querySelectorAll('.pestana');
    botones.forEach(function (boton) {
      boton.addEventListener('click', function () {
        botones.forEach(function (b) {
          b.classList.remove('activa');
          b.setAttribute('aria-selected', 'false');
          var panel = document.getElementById(b.dataset.pestana);
          if (panel) panel.hidden = true;
        });
        boton.classList.add('activa');
        boton.setAttribute('aria-selected', 'true');
        var panel = document.getElementById(boton.dataset.pestana);
        if (panel) panel.hidden = false;
        history.replaceState(null, '', '#' + boton.dataset.pestana);
      });
    });
 
    // Abrir la pestaña indicada en la dirección (por ejemplo operacion.html#cambios)
    var inicial = location.hash.slice(1);
    var botonInicial = inicial && grupo.querySelector('.pestana[data-pestana="' + inicial + '"]');
    if (botonInicial) botonInicial.click();
  });
 
  // Botones que abren una pestaña de la misma página: <a data-ir="id">
  document.querySelectorAll('[data-ir]').forEach(function (enlace) {
    enlace.addEventListener('click', function (e) {
      var boton = document.querySelector('.pestana[data-pestana="' + enlace.dataset.ir + '"]');
      if (!boton) return;
      e.preventDefault();
      boton.click();
      boton.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
 
  // Selección de alternativas (portal del cliente)
  var alternativas = document.querySelectorAll('.alternativa');
  var botonConfirmar = document.getElementById('confirmar-seleccion');
  alternativas.forEach(function (alt) {
    var radio = alt.querySelector('input[type="radio"]');
    radio.addEventListener('change', function () {
      alternativas.forEach(function (a) { a.classList.remove('elegida'); });
      alt.classList.add('elegida');
      if (botonConfirmar) botonConfirmar.disabled = false;
    });
  });
 
  // Mostrar u ocultar formularios desplegables: <button data-alternar="id">
  document.querySelectorAll('[data-alternar]').forEach(function (boton) {
    boton.addEventListener('click', function () {
      var destino = document.getElementById(boton.dataset.alternar);
      if (!destino) return;
      destino.hidden = !destino.hidden;
      if (!destino.hidden) {
        var primerCampo = destino.querySelector('input, select, textarea');
        if (primerCampo) primerCampo.focus();
      }
    });
  });
 
  // Filtro rápido de tablas: <input data-filtrar="id-de-tabla">
  document.querySelectorAll('[data-filtrar]').forEach(function (campo) {
    var tabla = document.getElementById(campo.dataset.filtrar);
    if (!tabla) return;
    campo.addEventListener('input', function () {
      var texto = campo.value.trim().toLowerCase();
      tabla.querySelectorAll('tbody tr').forEach(function (fila) {
        fila.hidden = texto !== '' && fila.textContent.toLowerCase().indexOf(texto) === -1;
      });
    });
  });
});

// Portal de clientes: confirmaciones y recorrido de bienvenida
document.addEventListener('DOMContentLoaded', function () {

  // Formularios con <form data-confirmar="mensaje">: piden confirmación antes de enviar
  document.querySelectorAll('form[data-confirmar]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!window.confirm(form.dataset.confirmar)) e.preventDefault();
    });
  });

  // Recorrido de bienvenida (se muestra la primera vez que entra desde este navegador)
  var tour = document.getElementById('tour');
  if (tour) {
    var pasos = tour.querySelectorAll('.tour-paso');
    var puntos = tour.querySelector('.tour-puntos');
    var siguiente = tour.querySelector('[data-tour-siguiente]');
    var actual = 0;
    pasos.forEach(function () { puntos.appendChild(document.createElement('i')); });
    var mostrar = function (n) {
      actual = n;
      pasos.forEach(function (p, i) { p.hidden = i !== n; });
      puntos.querySelectorAll('i').forEach(function (d, i) { d.classList.toggle('on', i === n); });
      siguiente.textContent = n === pasos.length - 1 ? 'Empezar' : 'Siguiente';
    };
    var cerrar = function () {
      tour.hidden = true;
      try { localStorage.setItem('arp_tour_visto', '1'); } catch (e) {}
    };
    var abrir = function () { mostrar(0); tour.hidden = false; siguiente.focus(); };
    siguiente.addEventListener('click', function () { if (actual >= pasos.length - 1) cerrar(); else mostrar(actual + 1); });
    tour.querySelector('[data-tour-cerrar]').addEventListener('click', cerrar);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !tour.hidden) cerrar(); });
    document.querySelectorAll('[data-tour-abrir]').forEach(function (b) { b.addEventListener('click', function (e) { e.preventDefault(); abrir(); }); });
    var visto = false;
    try { visto = localStorage.getItem('arp_tour_visto') === '1'; } catch (e) {}
    if (!visto && document.getElementById('demo-panel') === null && /\/cliente\/reservas\.php/.test(location.pathname)) abrir();
  }
});


// Secciones plegables: un enlace “#id” (o un botón con la clase “abrir”) abre la sección y baja hasta ella
(function () {
  function abrir(id, desplazar) {
    var el = id && document.getElementById(id);
    if (!el || el.tagName !== 'DETAILS') { return false; }
    el.open = true;
    if (desplazar) { el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    return true;
  }
  document.querySelectorAll('a.abrir').forEach(function (a) {
    a.addEventListener('click', function (ev) {
      var id = (a.getAttribute('href') || '').replace('#', '');
      if (abrir(id, true)) { ev.preventDefault(); history.replaceState(null, '', '#' + id); }
    });
  });
  window.addEventListener('hashchange', function () { abrir(location.hash.slice(1), true); });
  abrir(location.hash.slice(1), true);
})();

// Filas clickeables: en cualquier tabla, una fila que tiene el enlace de una reserva (a.ref) se puede tocar entera
// y lleva a ese enlace. Los botones, enlaces y campos de la fila siguen funcionando normalmente.
(function () {
  var INTERACTIVOS = 'a, button, input, select, textarea, label, summary, form';
  document.querySelectorAll('tbody tr').forEach(function (tr) {
    var a = tr.querySelector('a.ref');
    if (!a) { return; }
    tr.classList.add('fila-link');
    tr.title = 'Abrir ' + a.textContent.trim();
    tr.addEventListener('click', function (ev) {
      if (ev.target.closest(INTERACTIVOS)) { return; }                  // tocó un botón o enlace propio de la fila
      if (window.getSelection && String(window.getSelection()).length) { return; }  // estaba seleccionando texto para copiar
      if (ev.ctrlKey || ev.metaKey) { window.open(a.href, '_blank'); return; }
      location.href = a.href;
    });
    tr.addEventListener('auxclick', function (ev) {                    // clic con la rueda: abre en otra pestaña
      if (ev.button === 1 && !ev.target.closest(INTERACTIVOS)) { window.open(a.href, '_blank'); }
    });
  });
})();

// Botón "← Volver" de la ficha: vuelve a la pantalla de donde se vino (con sus filtros).
// Si se entró directo, o la pantalla anterior es la misma ficha (por ejemplo, después de guardar algo), va al enlace del botón.
(function () {
  document.querySelectorAll('[data-volver]').forEach(function (a) {
    a.addEventListener('click', function (ev) {
      try {
        var r = document.referrer ? new URL(document.referrer) : null;
        if (r && r.origin === location.origin && r.pathname !== location.pathname && history.length > 1) {
          ev.preventDefault(); history.back();
        }
      } catch (e) {}
    });
  });
})();

// Vista previa de documentos: los botones "Ver" (data-previa) abren el archivo en una ventana dentro de la página
(function () {
  var botones = document.querySelectorAll('a[data-previa]');
  if (!botones.length) { return; }
  var caja = document.createElement('div');
  caja.className = 'previa'; caja.hidden = true;
  caja.setAttribute('role', 'dialog'); caja.setAttribute('aria-modal', 'true'); caja.setAttribute('aria-labelledby', 'previa-titulo');
  caja.innerHTML = '<div class="previa-caja"><div class="previa-cab"><div><strong id="previa-titulo"></strong><div class="chico suave" id="previa-nombre"></div></div>' +
    '<div class="acciones"><a class="boton boton-secundario boton-chico" id="previa-pestana" target="_blank" rel="noopener">Abrir en otra pestaña</a>' +
    '<a class="boton boton-primario boton-chico" id="previa-descargar">Descargar</a>' +
    '<button type="button" class="previa-cerrar" aria-label="Cerrar">×</button></div></div><div class="previa-cuerpo" id="previa-cuerpo"></div></div>';
  document.body.appendChild(caja);
  var cuerpo = caja.querySelector('#previa-cuerpo'), ultimo = null;
  function cerrar() { caja.hidden = true; cuerpo.innerHTML = ''; document.body.classList.remove('previa-abierta'); if (ultimo) { ultimo.focus(); } }
  caja.addEventListener('click', function (ev) { if (ev.target === caja || ev.target.closest('.previa-cerrar')) { cerrar(); } });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && !caja.hidden) { cerrar(); } });
  botones.forEach(function (b) {
    b.addEventListener('click', function (ev) {
      if (ev.ctrlKey || ev.metaKey || ev.shiftKey || ev.button !== 0) { return; }   // Ctrl+clic: que abra en otra pestaña como siempre
      ev.preventDefault();
      ultimo = b;
      caja.querySelector('#previa-titulo').textContent = b.dataset.titulo || 'Documento';
      caja.querySelector('#previa-nombre').textContent = b.dataset.nombre || '';
      caja.querySelector('#previa-descargar').href = b.dataset.descargar || b.href;
      var pest = caja.querySelector('#previa-pestana');
      pest.href = b.href; pest.hidden = b.dataset.previa === 'no';
      cuerpo.innerHTML = '';
      if (b.dataset.previa === 'img') {
        var img = document.createElement('img'); img.src = b.href; img.alt = b.dataset.titulo || ''; cuerpo.appendChild(img);
      } else if (b.dataset.previa === 'pdf' || b.dataset.previa === 'txt') {
        var fr = document.createElement('iframe'); fr.src = b.href; fr.title = b.dataset.titulo || 'Documento'; cuerpo.appendChild(fr);
      } else {
        cuerpo.innerHTML = '<div class="previa-sin"><p><strong>Este tipo de archivo no se puede ver en el navegador.</strong></p>' +
          '<p class="suave">Las planillas, los documentos de Word y los correos guardados se abren con su programa. Descargalo y abrilo en tu computadora.</p></div>';
      }
      caja.hidden = false; document.body.classList.add('previa-abierta');
      caja.querySelector('.previa-cerrar').focus();
    });
  });
})();
