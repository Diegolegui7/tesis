// Panel de la demostración guiada: consulta el estado cada 2 segundos y muestra el paso en el que está la persona
(function () {
  var panel = document.getElementById('demo-panel');
  if (!panel) { return; }
  var base = panel.dataset.base, csrf = panel.dataset.csrf;
  var $ = function (id) { return document.getElementById(id); };
  var hechosAntes = null, avisoTimer = null, ultimo = null;
  try { var g = sessionStorage.getItem('arp_demo_hechos'); if (g !== null) { hechosAntes = parseInt(g, 10); } } catch (e) {}

  function post(accion, extra) {
    var fd = new FormData();
    fd.append('csrf', csrf); fd.append('accion', accion);
    Object.keys(extra || {}).forEach(function (k) { fd.append(k, extra[k]); });
    return fetch(base + 'demo/accion.php', { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
  }
  function consultar() {
    fetch(base + 'demo/estado.php', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); }).then(function (e) { pintar(e); ajustar(); }).catch(function () {});
  }
  function esc(t) { var d = document.createElement('div'); d.textContent = t; return d.innerHTML; }

  function pintar(e) {
    if (!e || !e.activo) { panel.hidden = true; return; }
    panel.hidden = false;
    ultimo = e;
    var hechos = e.pasos.filter(function (p) { return p.hecho; }).length;
    $('demo-barra-i').style.width = Math.round(100 * hechos / e.total) + '%';
    if (hechosAntes !== null && hechos > hechosAntes) {
      var ok = $('demo-ok');
      ok.textContent = '✔ ¡Paso completado: ' + e.pasos[hechos - 1].titulo + '!';
      ok.hidden = false;
      clearTimeout(avisoTimer);
      avisoTimer = setTimeout(function () { ok.hidden = true; }, 5000);
    }
    hechosAntes = hechos;
    try { sessionStorage.setItem('arp_demo_hechos', String(hechos)); } catch (e) {}

    var quien = $('demo-quien');
    if (e.terminado) {
      $('demo-prog').textContent = 'Terminada';
      $('demo-titulo').textContent = '¡Listo! Recorriste todo el circuito';
      $('demo-texto').textContent = 'Un cliente pidió una reserva, ARPAFLU la aceptó, se confirmó el lugar, hubo un cambio de buque, el cliente lo confirmó y envió un documento, el barco zarpó y se vio qué pasa cuando no hay lugar. Podés reiniciar la demo y probar otro camino.';
      poner(quien, '');
      $('demo-saltar').hidden = true;
      resaltar(null);
      return;
    }
    $('demo-saltar').hidden = false;
    var p = e.pasos[e.actual];
    $('demo-prog').textContent = 'Paso ' + (e.actual + 1) + ' de ' + e.total;
    $('demo-titulo').textContent = p.titulo;
    $('demo-texto').textContent = p.texto;
    var nombre = esc(p.quien_nombre.split(' ')[0]);
    if (e.usuario !== p.quien) {
      // 1) Está con otro usuario: un solo botón que entra como la persona correcta y lo lleva a la pantalla del paso
      poner(quien, '<div class="demo-estoy demo-cambiar">Este paso lo hace <strong>' + esc(p.quien_nombre) + '</strong>.</div>' +
        '<button type="button" class="demo-boton" data-entrar="' + esc(p.quien) + '"' + (p.ir ? ' data-ir="' + esc(p.ir.ruta) + '"' : '') + '>Entrar como ' + nombre + '</button>');
      resaltar(null);
    } else if (p.ir && !enPantalla(p.ir.ruta)) {
      // 2) Es la persona correcta pero está en otra pantalla: primero ir a la pantalla del paso
      poner(quien, '<div class="demo-estoy demo-cambiar">Estás en otra pantalla. <strong>Primero tocá este botón:</strong></div>' +
        '<a class="demo-boton" href="' + base + esc(p.ir.ruta) + '">' + esc(p.ir.texto) + ' →</a>');
      resaltar(null);
    } else {
      // 3) Está en el lugar correcto: los pasitos y lo que hay que tocar, marcado en la pantalla
      var lista = (p.pasos || []).map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('');
      poner(quien, '<div class="demo-estoy">✔ Estás en el lugar correcto. Hacé esto:</div><ol class="demo-pasitos">' + lista + '</ol>' +
        (p.ir ? '' : '<button type="button" class="demo-boton" data-entrar="' + esc(p.quien) + '">Entrar como ' + nombre + '</button>'));
      resaltar(p.resaltar ? p : null);
    }
  }

  // Solo cambia el contenido si es distinto (el panel se actualiza cada 2 segundos y así no parpadea ni pierde el foco)
  function poner(el, html) { if (el.dataset.html !== html) { el.innerHTML = html; el.dataset.html = html; } }

  // ¿La pantalla actual es la del paso? (misma página y, si la ruta lo indica, el mismo id de reserva)
  function enPantalla(ruta) {
    var u = new URL(base + ruta, location.href);
    if (location.pathname.replace(/\/+$/, '') !== u.pathname.replace(/\/+$/, '')) { return false; }
    var id = u.searchParams.get('id');
    return !id || new URLSearchParams(location.search).get('id') === id;
  }

  // Marca en naranja (y lleva la pantalla hasta) lo que hay que tocar en este paso
  var resaltadoDe = null;
  function resaltar(p) {
    document.querySelectorAll('.demo-resaltado').forEach(function (x) { if (!p || x.dataset.demoPaso !== String(p.id)) { x.classList.remove('demo-resaltado'); } });
    if (!p) { resaltadoDe = null; return; }
    var sel = p.resaltar[0], txt = p.resaltar[1];
    var el = Array.prototype.find.call(document.querySelectorAll(sel), function (x) { return !txt || x.textContent.indexOf(txt) >= 0; });
    if (!el) { return; }
    var det = el.closest('details'); if (det && !det.open) { det.open = true; }
    el.classList.add('demo-resaltado'); el.dataset.demoPaso = String(p.id);
    if (resaltadoDe !== p.id) {           // solo la primera vez en cada paso, para no mover la pantalla cada 2 segundos
      resaltadoDe = p.id;
      setTimeout(function () { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 150);
    }
  }

  panel.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-entrar]');
    if (b) {
      b.disabled = true;
      post('entrar', { correo: b.dataset.entrar, ir: b.dataset.ir || '' }).then(function (j) { if (j.ok) { location.href = j.redirect; } else { alert(j.error || 'No se pudo entrar.'); b.disabled = false; } });
    }
  });
  $('demo-saltar').addEventListener('click', function () { post('saltar').then(consultar); });
  $('demo-ocultar').addEventListener('click', function () { post('ocultar').then(function () { location.reload(); }); });
  $('demo-reiniciar').addEventListener('click', function () {
    if (!confirm('¿Reiniciar la demo? Se borran los datos que cargaste y se vuelve a empezar desde el paso 1.')) { return; }
    post('reiniciar').then(function (j) { if (j.ok) { location.href = j.redirect; } else { alert(j.error || 'No se pudo reiniciar.'); } });
  });
  $('demo-min').addEventListener('click', function () {
    var mini = panel.classList.toggle('demo-mini');
    $('demo-min').textContent = mini ? '+' : '–';
    try { localStorage.setItem('arp_demo_mini', mini ? '1' : '0'); } catch (e) {}
    ajustar();
  });
  try { if (localStorage.getItem('arp_demo_mini') === '1') { panel.classList.add('demo-mini'); $('demo-min').textContent = '+'; } } catch (e) {}

  // ---- Mover el cuadro: se arrastra desde la barra de arriba y queda donde se suelta (se recuerda entre pantallas)
  var CLAVE_POS = 'arp_demo_pos', arrastre = null;
  function ubicar(x, y) {
    var w = panel.offsetWidth, h = panel.offsetHeight;
    x = Math.max(0, Math.min(x, window.innerWidth - w));
    y = Math.max(0, Math.min(y, window.innerHeight - h));
    panel.style.left = x + 'px'; panel.style.top = y + 'px';
    panel.style.right = 'auto'; panel.style.bottom = 'auto';
    return { x: x, y: y };
  }
  function ajustar() {          // si cambió el tamaño del cuadro o de la ventana, que no quede afuera
    if (panel.style.top) { ubicar(parseFloat(panel.style.left), parseFloat(panel.style.top)); }
  }
  $('demo-cab').addEventListener('pointerdown', function (ev) {
    if (ev.button !== 0 || ev.target.closest('button')) { return; }
    var r = panel.getBoundingClientRect();
    arrastre = { dx: ev.clientX - r.left, dy: ev.clientY - r.top };
    panel.classList.add('demo-arrastrando');
    try { this.setPointerCapture(ev.pointerId); } catch (e) {}
    ev.preventDefault();
  });
  $('demo-cab').addEventListener('pointermove', function (ev) {
    if (arrastre) { ubicar(ev.clientX - arrastre.dx, ev.clientY - arrastre.dy); }
  });
  function soltar() {
    if (!arrastre) { return; }
    arrastre = null;
    panel.classList.remove('demo-arrastrando');
    try { localStorage.setItem(CLAVE_POS, JSON.stringify({ x: parseFloat(panel.style.left), y: parseFloat(panel.style.top) })); } catch (e) {}
  }
  $('demo-cab').addEventListener('pointerup', soltar);
  $('demo-cab').addEventListener('pointercancel', soltar);
  $('demo-manija').addEventListener('dblclick', function () {   // volver a la posición original
    panel.style.left = panel.style.top = panel.style.right = panel.style.bottom = '';
    try { localStorage.removeItem(CLAVE_POS); } catch (e) {}
  });
  try { var pos = JSON.parse(localStorage.getItem(CLAVE_POS) || 'null'); if (pos) { ubicar(pos.x, pos.y); } } catch (e) {}
  window.addEventListener('resize', ajustar);

  consultar();
  setInterval(consultar, 2000);
})();
