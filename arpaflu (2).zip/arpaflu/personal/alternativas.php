<?php
// SS2 · Bookings reservados por anticipado y alternativas para los clientes que eligen entre varios (caso OLEGA, RF-09)
// ARPAFLU reserva espacio por adelantado con las navieras y lo ofrece a un cliente por vez; el cliente elige desde su portal (cliente/alternativas.php).
// Mientras no se usa, ARPAFLU lo va roleando a buques próximos; si se usa para otro cliente deja de ofrecerse, y si ya no se puede postergar se cancela (P4 y P8).
require_once __DIR__ . '/../partes/layout.php';
$u = requerir_empleado('crear_operaciones');

if (es_post()) {
    csrf_verificar();
    $accion = isset($_POST['accion']) ? $_POST['accion'] : 'cargar';

    // Acciones sobre un booking ya cargado: rolear, usar para otro cliente, cancelar
    if (in_array($accion, ['rolear', 'usada', 'cancelar'], true)) {
        $alt = fila('SELECT a.*, c.empresa FROM alternativas a JOIN clientes c ON c.id = a.cliente_id WHERE a.id = ?', [(int) (isset($_POST['id']) ? $_POST['id'] : 0)]);
        if (!$alt) {
            flash('error', 'No se encontró el booking.');
        } elseif (!puede_actuar_cliente($alt['cliente_id'])) {
            flash('error', 'No tenés autorización para actuar sobre los bookings de ' . $alt['empresa'] . '.');
        } elseif (!in_array($alt['estado'], ['disponible', 'no_elegida'], true)) {
            flash('error', 'Este booking ya no admite cambios: ' . ($alt['estado'] === 'elegida' ? 'el cliente lo eligió (la reserva se crea desde “Crear la operación”)' : 'ya fue ' . ($alt['estado'] === 'usada' ? 'usado para otro cliente' : 'cancelado')) . '.');
        } elseif ($accion === 'rolear') {
            $buque = trim(isset($_POST['buque']) ? $_POST['buque'] : '');
            $etd = parse_fecha(isset($_POST['etd']) ? $_POST['etd'] : '');
            $cut = parse_fecha(isset($_POST['cutoff_doc']) ? $_POST['cutoff_doc'] : '', true);
            if ($buque === '' || $etd === false || $etd === null || $cut === false) {
                flash('error', 'Para rolear indicá el buque nuevo y su ETD (dd/mm/aaaa); el cut-off, si lo sabés (dd/mm/aaaa hh:mm).');
            } else {
                $nota = date('d/m/Y') . ': roleo de «' . $alt['buque'] . '» (ETD ' . f_corta($alt['etd']) . ') a «' . $buque . '» (ETD ' . f_corta($etd) . '), por ' . $u['nombre'] . '.';
                ejecutar('UPDATE alternativas SET buque = ?, etd = ?, cutoff_doc = COALESCE(?, cutoff_doc), roleos = roleos + 1, notas = CONCAT_WS("\n", notas, ?) WHERE id = ?',
                    [$buque, $etd, $cut, $nota, $alt['id']]);
                flash('ok', 'Booking roleado a ' . $buque . '. Lleva ' . ($alt['roleos'] + 1) . ' roleo' . ($alt['roleos'] + 1 == 1 ? '' : 's') . '.');
            }
        } else {
            $motivo = trim(isset($_POST['motivo']) ? $_POST['motivo'] : '');
            if ($accion === 'cancelar' && $motivo === '') {
                flash('error', 'Indicá el motivo de la cancelación (por ejemplo: ya no se puede postergar más).');
            } else {
                $nuevo = $accion === 'usada' ? 'usada' : 'cancelada';
                ejecutar('UPDATE alternativas SET estado = ?, motivo_baja = ?, baja_en = NOW(), notas = CONCAT_WS("\n", notas, ?) WHERE id = ?',
                    [$nuevo, $motivo !== '' ? $motivo : null, date('d/m/Y') . ': ' . ($nuevo === 'usada' ? 'se usó para otro cliente' : 'cancelado') . ' por ' . $u['nombre'] . ($motivo !== '' ? ' (' . $motivo . ')' : '') . '.', $alt['id']]);
                flash('ok', $nuevo === 'usada' ? 'Listo: el booking quedó marcado como usado para otro cliente y deja de ofrecerse.' : 'Booking cancelado. Queda como antecedente.');
            }
        }
        redirigir('alternativas.php');
    }

    $cliente_id = (int) (isset($_POST['cliente_id']) ? $_POST['cliente_id'] : 0);
    $c = fila('SELECT * FROM clientes WHERE id = ? AND activo = 1 AND selecciona_alternativas = 1', [$cliente_id]);
    $grupo = trim(isset($_POST['grupo']) ? $_POST['grupo'] : '');
    $booking = trim(isset($_POST['booking']) ? $_POST['booking'] : '');
    $naviera = (int) (isset($_POST['naviera_id']) ? $_POST['naviera_id'] : 0);
    $buque = trim(isset($_POST['buque']) ? $_POST['buque'] : '');
    $via = trim(isset($_POST['via']) ? $_POST['via'] : '');
    $etd = parse_fecha(isset($_POST['etd']) ? $_POST['etd'] : '');
    $eta = parse_fecha(isset($_POST['eta']) ? $_POST['eta'] : '');
    $cut = parse_fecha(isset($_POST['cutoff_doc']) ? $_POST['cutoff_doc'] : '', true);
    $flete = isset($_POST['flete']) ? $_POST['flete'] : '';
    $libres = trim(isset($_POST['dias_libres']) ? $_POST['dias_libres'] : '');
    $errores = [];
    if (!$c) { $errores[] = 'Elegí un cliente que seleccione entre alternativas.'; }
    elseif (!puede_actuar_cliente($cliente_id)) { $errores[] = 'No tenés autorización para cargar alternativas de ' . $c['empresa'] . '.'; }
    if ($grupo === '') { $errores[] = 'Indicá el nombre del grupo (por ejemplo: Próximo embarque · Buenos Aires → Rotterdam).'; }
    if ($booking === '') { $errores[] = 'Indicá el número del booking que ARPAFLU reservó por anticipado.'; }
    if (!$naviera) { $errores[] = 'Elegí una naviera.'; }
    if ($buque === '') { $errores[] = 'Indicá el buque y viaje.'; }
    if ($flete === '' || !is_numeric($flete) || $flete < 0) { $errores[] = 'Indicá el flete (un número).'; }
    foreach (['ETD' => $etd, 'ETA' => $eta, 'cut-off documental' => $cut] as $n => $x) {
        if ($x === false) { $errores[] = 'La fecha de ' . $n . ' no se entiende (usá dd/mm/aaaa o dd/mm/aaaa hh:mm).'; }
    }
    if ($libres !== '' && !ctype_digit($libres)) { $errores[] = 'Los días libres deben ser un número entero.'; }
    if ($errores) {
        foreach ($errores as $er) { flash('error', $er); }
        redirigir('alternativas.php');
    }
    // la etiqueta (A, B, C…) sigue la serie del grupo; si el grupo ya tiene una elegida o todas resueltas, la nueva se suma igual
    $n = (int) valor('SELECT COUNT(*) FROM alternativas WHERE cliente_id = ? AND grupo = ?', [$cliente_id, $grupo]);
    $etiqueta = chr(ord('A') + min($n, 25));
    $carga = trim(isset($_POST['carga']) ? $_POST['carga'] : '');
    ejecutar(
        'INSERT INTO alternativas (cliente_id, grupo, carga, etiqueta, booking, naviera_id, buque, via, etd, eta, cutoff_doc, flete, dias_libres, estado)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,"disponible")',
        [$cliente_id, $grupo, $carga !== '' ? $carga : null, $etiqueta, $booking, $naviera, $buque, $via !== '' ? $via : 'Directa', $etd, $eta, $cut, $flete, $libres !== '' ? (int) $libres : null]
    );
    flash('ok', 'Booking ' . $booking . ' cargado como alternativa ' . $etiqueta . ' en “' . $grupo . '”. ' . $c['empresa'] . ' ya puede elegirla desde su portal.');
    redirigir('alternativas.php');
}

$estado_q = isset($_GET['estado']) ? $_GET['estado'] : '';
$estados_ok = ['disponible', 'elegida', 'no_elegida', 'usada', 'cancelada'];
$alts = consulta(
    "SELECT a.*, c.empresa, n.nombre AS naviera, e.nombre AS eligio, o.referencia
     FROM alternativas a JOIN clientes c ON c.id = a.cliente_id LEFT JOIN navieras n ON n.id = a.naviera_id
     LEFT JOIN usuarios e ON e.id = a.elegida_por LEFT JOIN operaciones o ON o.id = a.operacion_id"
    . (in_array($estado_q, $estados_ok, true) ? " WHERE a.estado = '" . $estado_q . "'" : '')
    . " ORDER BY a.creado DESC, a.cliente_id, a.grupo, a.etiqueta"
);
$grupos = [];
foreach ($alts as $a) { $grupos[$a['empresa'] . '|' . $a['grupo']][] = $a; }
$clientes = consulta('SELECT id, empresa FROM clientes WHERE activo = 1 AND selecciona_alternativas = 1 ORDER BY empresa');
$navieras = consulta('SELECT id, nombre FROM navieras ORDER BY nombre');
$txt = ['disponible' => ['Ofrecido', 'estado-info'], 'elegida' => ['Elegido', 'estado-ok'], 'no_elegida' => ['No elegido', 'estado-neutro'],
        'usada' => ['Usado para otro cliente', 'estado-neutro'], 'cancelada' => ['Cancelado', 'estado-peligro']];
$cuenta = [];
foreach (consulta('SELECT estado, COUNT(*) n FROM alternativas GROUP BY estado') as $r) { $cuenta[$r['estado']] = (int) $r['n']; }

cabecera_personal('Alternativas', 'alternativas');
?>
      <div class="encabezado-pagina">
        <div>
          <h1>Bookings reservados por anticipado</h1>
          <p>Espacio que ARPAFLU reservó con las navieras antes del pedido y ofrece a un cliente por vez (hoy, OLEGA). El cliente elige y el booking se rolea al buque y la cantidad que necesita.</p>
        </div>
        <div class="acciones">
          <button type="button" class="boton boton-primario" data-alternar="form-alternativa">+ Cargar booking anticipado</button>
        </div>
      </div>

      <form class="filtros" action="alternativas.php" method="get" style="margin-bottom:14px">
        <select name="estado" aria-label="Estado">
          <option value="">Todos los estados</option>
          <?php foreach ($txt as $k => $t) { ?><option value="<?= e($k) ?>"<?= $estado_q === $k ? ' selected' : '' ?>><?= e($t[0]) ?><?= isset($cuenta[$k]) ? ' (' . $cuenta[$k] . ')' : '' ?></option><?php } ?>
        </select>
        <button type="submit" class="boton boton-secundario">Filtrar</button>
      </form>

      <form id="form-alternativa" class="tarjeta" action="alternativas.php" method="post" hidden style="margin-bottom:18px">
        <?= csrf_campo() ?>
        <input type="hidden" name="accion" value="cargar">
        <div class="tarjeta-cabecera"><h2>Cargar booking reservado por anticipado</h2></div>
        <div class="tarjeta-cuerpo formulario">
          <div class="campos">
            <div class="campo">
              <label for="alt-cliente">Cliente al que se ofrece</label>
              <select id="alt-cliente" name="cliente_id" required>
                <option value="">Elegí un cliente</option>
                <?php foreach ($clientes as $c) { ?><option value="<?= (int) $c['id'] ?>"><?= e($c['empresa']) ?></option><?php } ?>
              </select>
            </div>
            <div class="campo">
              <label for="alt-grupo">Grupo (mismo texto para todos los bookings del embarque)</label>
              <input type="text" id="alt-grupo" name="grupo" maxlength="80" placeholder="Próximo embarque · Buenos Aires → Rotterdam" required>
            </div>
            <div class="campo">
              <label for="alt-booking">Número de booking</label>
              <input type="text" id="alt-booking" name="booking" maxlength="40" placeholder="254AR0091234" required>
            </div>
            <div class="campo">
              <label for="alt-carga">Cantidad y tipo de contenedores</label>
              <input type="text" id="alt-carga" name="carga" maxlength="60" placeholder="2 × 40' HC">
            </div>
            <div class="campo">
              <label for="alt-naviera">Naviera</label>
              <select id="alt-naviera" name="naviera_id" required>
                <?php foreach ($navieras as $n) { ?><option value="<?= (int) $n['id'] ?>"><?= e($n['nombre']) ?></option><?php } ?>
              </select>
            </div>
            <div class="campo">
              <label for="alt-buque">Buque y viaje</label>
              <input type="text" id="alt-buque" name="buque" maxlength="120" required>
            </div>
            <div class="campo">
              <label for="alt-via">Vía</label>
              <input type="text" id="alt-via" name="via" maxlength="60" placeholder="Directa">
            </div>
            <div class="campo">
              <label for="alt-etd">ETD</label>
              <input type="text" id="alt-etd" name="etd" placeholder="dd/mm/aaaa">
            </div>
            <div class="campo">
              <label for="alt-eta">ETA</label>
              <input type="text" id="alt-eta" name="eta" placeholder="dd/mm/aaaa">
            </div>
            <div class="campo">
              <label for="alt-cut">Cut-off documental</label>
              <input type="text" id="alt-cut" name="cutoff_doc" placeholder="dd/mm/aaaa hh:mm">
            </div>
            <div class="campo">
              <label for="alt-flete">Flete (US$ por contenedor)</label>
              <input type="number" id="alt-flete" name="flete" min="0" step="0.01" required>
            </div>
            <div class="campo">
              <label for="alt-libres">Días libres en destino</label>
              <input type="number" id="alt-libres" name="dias_libres" min="0" step="1">
            </div>
          </div>
          <div class="pie-formulario">
            <button type="button" class="boton boton-secundario" data-alternar="form-alternativa">Cancelar</button>
            <button type="submit" class="boton boton-primario">Guardar booking</button>
          </div>
        </div>
      </form>

      <?php foreach ($grupos as $clave => $lista) { $p = $lista[0]; $elegida = null; foreach ($lista as $x) { if ($x['estado'] === 'elegida') { $elegida = $x; } } ?>
      <section class="tarjeta" style="margin-bottom:18px">
        <div class="tarjeta-cabecera">
          <h2><?= e($p['empresa']) ?> · <?= e($p['grupo']) ?></h2>
          <?php if ($elegida && !$elegida['referencia']) { ?>
            <a class="boton boton-secundario boton-chico" href="nueva-operacion.php?alternativa_id=<?= (int) $elegida['id'] ?>">Crear la operación con la elegida</a>
          <?php } ?>
        </div>
        <div class="tabla-contenedor">
          <table>
            <thead><tr><th>Alt.</th><th>Booking</th><th>Buque y vía</th><th>ETD y cut-off</th><th class="derecha">Flete / cont.</th><th>Estado</th><th>Seguimiento</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($lista as $a) { $abierta = in_array($a['estado'], ['disponible', 'no_elegida'], true); ?>
              <tr>
                <td><strong><?= e($a['etiqueta']) ?></strong></td>
                <td class="num"><?= $a['booking'] ? e($a['booking']) : '<span class="suave">—</span>' ?><div class="chico suave"><?= e($a['carga']) ?></div></td>
                <td><?= e($a['buque']) ?><div class="chico suave"><?= e($a['naviera']) ?> · <?= e($a['via']) ?><?= (int) $a['roleos'] ? ' · ' . (int) $a['roleos'] . ' roleo' . ((int) $a['roleos'] == 1 ? '' : 's') : '' ?></div></td>
                <td class="num"><?= e(f_corta($a['etd'])) ?><div class="chico suave"><?= e(f_hora($a['cutoff_doc'])) ?></div></td>
                <td class="num derecha"><?= e(dinero($a['flete'])) ?></td>
                <td><?= badge($txt[$a['estado']][0], $txt[$a['estado']][1]) ?></td>
                <td class="envolver"><?php
                    if ($a['estado'] === 'elegida') { echo e($a['eligio']) . '<div class="chico suave">' . e(f_completa($a['elegida_en'])) . ($a['referencia'] ? ' · ' . e($a['referencia']) : '') . '</div>'; }
                    elseif ($a['baja_en']) { echo '<div class="chico suave">' . e(f_completa($a['baja_en'])) . ($a['motivo_baja'] ? ' · ' . e($a['motivo_baja']) : '') . '</div>'; }
                    else { echo '<span class="suave">—</span>'; } ?></td>
                <td>
                  <?php if ($abierta) { ?>
                  <details class="acciones-fila">
                    <summary class="boton boton-secundario boton-chico">Acciones</summary>
                    <form action="alternativas.php" method="post" class="formulario" style="min-width:250px;padding:8px 0">
                      <?= csrf_campo() ?><input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
                      <div class="campo"><label>Rolear a otro buque</label><input type="text" name="buque" maxlength="120" placeholder="Buque y viaje nuevo"></div>
                      <div class="campo"><input type="text" name="etd" placeholder="ETD nuevo (dd/mm/aaaa)"></div>
                      <div class="campo"><input type="text" name="cutoff_doc" placeholder="Cut-off nuevo (dd/mm/aaaa hh:mm)"></div>
                      <button type="submit" name="accion" value="rolear" class="boton boton-secundario boton-chico">Registrar roleo</button>
                      <div class="campo" style="margin-top:10px"><label>Motivo (para cancelar o al usarlo con otro cliente)</label><input type="text" name="motivo" maxlength="200"></div>
                      <button type="submit" name="accion" value="usada" class="boton boton-secundario boton-chico">Usado para otro cliente</button>
                      <button type="submit" name="accion" value="cancelar" class="boton boton-secundario boton-chico">Cancelar booking</button>
                    </form>
                  </details>
                  <?php } ?>
                </td>
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>
      </section>
      <?php } if (!$grupos) { ?>
      <section class="tarjeta"><div class="tarjeta-cuerpo"><p class="suave">No hay bookings cargados<?= $estado_q !== '' ? ' con ese estado' : '' ?>.</p></div></section>
      <?php } ?>
<?php pie_personal(); ?>
